using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Player : MonoBehaviour
{

    [Header("Player movement")]
    [SerializeField] private float moveSpeed = 10f;
    [SerializeField] private float jumpForce = 12f;
    [SerializeField] private int numberOfJumps = 3;
    [SerializeField] private float bonusTime = 3f;

    private Rigidbody2D rb;
    private float xInput;
    private bool facingRight = true;
    private int extraJumps;
    private bool bonusSpeed = false;
    private bool bonusJump = false;
    private float timer = 0f;
    private float timer2 = 0f;
    private int fall = -10;

    [Header("Collision info")]
    [SerializeField] private float groundCheckDistance;
    [SerializeField] private LayerMask whatIsGround;
    private bool isOnGround;

    [Header("Game objects")]
    [SerializeField] private Transform spawnPos;
    [SerializeField] private GameObject coinparticle;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        extraJumps = numberOfJumps;
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape)) 
        {
            SceneManager.LoadScene("MainMenu");
        }

        if (isOnGround)
        {
            extraJumps = numberOfJumps;
        }

        if (transform.position.y <= fall)
        {
            Restart();
        }

        CollisionChecks();
        CheckInput();
        Movement();
        FlipController();
    }

    private void Movement()
    {
        if (bonusSpeed == true)
        {
            moveSpeed = 8f;
            timer += Time.deltaTime;
            if (timer >= bonusTime)
            {
                moveSpeed = 5f;
                timer = 0f;
                bonusSpeed = false;
            }
        }
        rb.velocity = new Vector2(xInput * moveSpeed, rb.velocity.y);
    }
    private void CheckInput()
    {
        xInput = Input.GetAxisRaw("Horizontal");
        if(Input.GetKeyDown(KeyCode.Space))
        {
            Jump();
        }
    }
    public void Flip()
    {
        facingRight = !facingRight;
        Vector3 Scaler = transform.localScale;
        Scaler.x *= -1;
        transform.localScale = Scaler;
    }

    private void FlipController()
    {
        if (facingRight == false && xInput > 0)
        {
            Flip();
        }
        else if (facingRight == true && xInput < 0)
        {
            Flip();
        }
    }

    private void Jump()
    {
        if (bonusJump == true)
        {
            numberOfJumps = 4;
            timer2 += Time.deltaTime;
            if (timer2 >= bonusTime)
            {
                numberOfJumps = 3;
                timer2 = 0f;
                bonusJump = false;
            }
        }
        if(extraJumps > 0)
        {
            rb.velocity = new Vector2(rb.velocity.x, jumpForce);
            extraJumps--;
        }
    }

    private void CollisionChecks()
    {
        isOnGround = Physics2D.OverlapCircle(transform.position, groundCheckDistance , whatIsGround);
    }

    public void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.CompareTag("YellowCrystal"))
        {
            Instantiate(coinparticle, other.transform.position, Quaternion.identity);
            bonusSpeed = true;
            Destroy(other.gameObject);
        }
        if (other.gameObject.CompareTag("BlueCrystal"))
        {
            Instantiate(coinparticle, other.transform.position, Quaternion.identity);
            bonusJump = true;
            Destroy(other.gameObject);
        }
        if (other.gameObject.CompareTag("BlackCrystal"))
        {
            Instantiate(coinparticle, other.transform.position, Quaternion.identity);
            SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
        }
    }
    void OnCollisionEnter2D(Collision2D other)
    {
        if (other.gameObject.CompareTag("Enemy"))
        {
            Restart();
        }

        if (other.gameObject.CompareTag("Spikes"))
        {
            Restart();
        }
    }

    private void Restart()
    {
        this.transform.position = spawnPos.position;
    }
}
